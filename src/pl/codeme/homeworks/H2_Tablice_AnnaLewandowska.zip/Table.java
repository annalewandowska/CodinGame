package pl.codeme.homeworks;

public abstract class Table {

	static int tableLn = 9;
}
