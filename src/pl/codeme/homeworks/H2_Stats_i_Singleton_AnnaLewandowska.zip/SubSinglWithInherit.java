package pl.codeme.homeworks;

public class SubSinglWithInherit extends SinglWithInherit {

	public SubSinglWithInherit(){
		super();
	}
	
	SinglWithInherit singl = new SinglWithInherit(); 
}
